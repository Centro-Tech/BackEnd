package school.sptech.projetoMima.core.adapter.Usuario;

public interface TokenGateway {
    String generate(Object authentication);
}
