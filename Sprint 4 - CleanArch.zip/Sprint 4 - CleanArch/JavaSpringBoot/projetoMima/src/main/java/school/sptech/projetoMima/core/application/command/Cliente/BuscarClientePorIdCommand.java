package school.sptech.projetoMima.core.application.command.Cliente;

public record BuscarClientePorIdCommand(
        Integer id
) { }
