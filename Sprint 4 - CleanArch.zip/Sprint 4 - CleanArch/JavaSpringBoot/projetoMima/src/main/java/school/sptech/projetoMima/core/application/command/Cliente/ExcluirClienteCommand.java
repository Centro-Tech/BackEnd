package school.sptech.projetoMima.core.application.command.Cliente;

public record ExcluirClienteCommand(
        Integer id
) { }
