package school.sptech.projetoMima.core.application.command.Fornecedor;

public record BuscarFornecedorPorIdCommand(Integer id) {
}
