package school.sptech.projetoMima.core.application.command.Item;

public record BuscarItemPorIdCommand(
        int id
) { }
