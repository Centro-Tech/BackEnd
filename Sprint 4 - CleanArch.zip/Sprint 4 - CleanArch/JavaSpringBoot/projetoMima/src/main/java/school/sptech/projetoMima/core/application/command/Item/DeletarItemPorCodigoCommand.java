package school.sptech.projetoMima.core.application.command.Item;

public record DeletarItemPorCodigoCommand(
        String codigo
) { }
