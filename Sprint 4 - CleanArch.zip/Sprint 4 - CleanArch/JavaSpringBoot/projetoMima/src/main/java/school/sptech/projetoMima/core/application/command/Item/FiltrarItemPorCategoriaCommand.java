package school.sptech.projetoMima.core.application.command.Item;

public record FiltrarItemPorCategoriaCommand(
        String Categoria
) { }
