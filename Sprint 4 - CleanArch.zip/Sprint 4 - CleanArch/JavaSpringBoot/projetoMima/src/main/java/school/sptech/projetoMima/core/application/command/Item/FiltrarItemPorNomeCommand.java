package school.sptech.projetoMima.core.application.command.item;

public record FiltrarItemPorNomeCommand(
        String nome
) { }
