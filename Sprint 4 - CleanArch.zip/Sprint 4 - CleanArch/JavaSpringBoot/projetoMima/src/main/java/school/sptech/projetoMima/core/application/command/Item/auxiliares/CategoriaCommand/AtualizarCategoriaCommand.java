package school.sptech.projetoMima.core.application.command.Item.auxiliares.CategoriaCommand;

public record AtualizarCategoriaCommand(
        Integer id,
        String nome
) { }
