package school.sptech.projetoMima.core.application.command.Item.auxiliares.CategoriaCommand;

public record CriarCategoriaCommand(
        String nome
) { }
