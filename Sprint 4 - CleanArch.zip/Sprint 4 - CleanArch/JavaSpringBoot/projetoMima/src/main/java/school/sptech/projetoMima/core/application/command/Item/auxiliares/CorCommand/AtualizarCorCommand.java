package school.sptech.projetoMima.core.application.command.Item.auxiliares.CorCommand;

public record AtualizarCorCommand(
        Integer id,
        String nome
) { }
