package school.sptech.projetoMima.core.application.command.Item.auxiliares.MaterialCommand;

public record CriarMaterialCommand(
        String nome
) { }
