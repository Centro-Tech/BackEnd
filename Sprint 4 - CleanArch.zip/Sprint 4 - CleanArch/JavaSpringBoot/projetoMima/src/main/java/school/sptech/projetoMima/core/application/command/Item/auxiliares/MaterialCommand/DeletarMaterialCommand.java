package school.sptech.projetoMima.core.application.command.Item.auxiliares.MaterialCommand;

public record DeletarMaterialCommand(
        Integer id
) { }