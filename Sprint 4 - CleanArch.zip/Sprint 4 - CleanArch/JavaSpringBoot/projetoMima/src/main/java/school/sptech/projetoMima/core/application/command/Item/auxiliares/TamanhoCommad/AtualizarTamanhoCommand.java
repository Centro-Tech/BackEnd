package school.sptech.projetoMima.core.application.command.Item.auxiliares.TamanhoCommad;

public record AtualizarTamanhoCommand(
        Integer id,
        String nome
) { }
