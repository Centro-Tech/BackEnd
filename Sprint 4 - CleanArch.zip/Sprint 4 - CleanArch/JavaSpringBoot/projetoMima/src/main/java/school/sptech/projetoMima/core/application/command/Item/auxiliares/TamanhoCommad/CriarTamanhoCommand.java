package school.sptech.projetoMima.core.application.command.Item.auxiliares.TamanhoCommad;

public record CriarTamanhoCommand(
        String nome
) { }
