package school.sptech.projetoMima.core.application.command.Usuario;

public class CriarUsuarioCommand {
    public String nome;
    public String telefone;
    public String email;
    public String cargo;
    public String endereco;
    public String senha;
}
