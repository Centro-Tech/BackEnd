package school.sptech.projetoMima.core.application.command.Usuario;

public class LoginUsuarioCommand {
    public String email;
    public String senha;
}
