package school.sptech.projetoMima.core.application.command.Usuario;

public class TrocarSenhaCommand {
    public String emailAutenticado;
    public String senhaAtual;
    public String novaSenha;
}