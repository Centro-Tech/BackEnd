package school.sptech.projetoMima.core.application.command.Venda;

import java.time.LocalDate;
import java.util.List;

public class CreateVendaCommand {
    private Integer clienteId;
    private Integer usuarioId;
    private List<Integer> itensVendaIds;
    private Double valorTotal;
    private LocalDate data;

    public CreateVendaCommand(Integer clienteId, List<Integer> itensVendaIds, Double valorTotal, LocalDate data) {
        this.clienteId = clienteId;
        this.usuarioId = usuarioId;
        this.itensVendaIds = itensVendaIds;
        this.valorTotal = valorTotal;
        this.data = data;
    }

    public Integer getClienteId() { return clienteId; }
    public Integer getUsuarioId() { return usuarioId; }
    public List<Integer> getItensVendaIds() { return itensVendaIds; }
    public Double getValorTotal() { return valorTotal; }
    public LocalDate getData() { return data; }
}
