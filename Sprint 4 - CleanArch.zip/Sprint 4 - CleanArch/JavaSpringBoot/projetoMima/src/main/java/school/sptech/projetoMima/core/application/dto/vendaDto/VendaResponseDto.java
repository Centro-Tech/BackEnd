package school.sptech.projetoMima.core.application.dto.vendaDto;

import school.sptech.projetoMima.core.application.dto.itemVendaDto.ItemVendaResponseDto;
import school.sptech.projetoMima.core.domain.ItemVenda;

import java.util.List;

public class VendaResponseDto {
    private Integer id;
    private Integer clienteId;
    private Integer usuarioId;
    private Double valorTotal;
    private List<ItemVenda> itensVenda;

    public VendaResponseDto(Integer id, Integer clienteId, Double valorTotal, List<ItemVenda> itensVenda) {
        this.id = id;
        this.clienteId = clienteId;
        this.usuarioId = usuarioId;
        this.valorTotal = valorTotal;
        this.itensVenda = itensVenda;
    }

    public Integer getId() {
        return id;
    }

    public Integer getClienteId() {
        return clienteId;
    }

    public Integer getUsuarioId() {
        return usuarioId;
    }

    public Double getValorTotal() {
        return valorTotal;
    }
    public List<ItemVenda> getItensVenda() {
        return itensVenda;
    }

    public void setValorTotal(Double valorTotal) {
        
    }

    public void setItensVenda(List<ItemVendaResponseDto> itensDto) {
    }
}
