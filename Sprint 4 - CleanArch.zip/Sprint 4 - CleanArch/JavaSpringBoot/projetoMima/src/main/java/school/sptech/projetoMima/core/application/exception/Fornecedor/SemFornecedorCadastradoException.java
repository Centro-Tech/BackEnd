package school.sptech.projetoMima.core.application.exception.Fornecedor;

public class SemFornecedorCadastradoException extends RuntimeException {
    public SemFornecedorCadastradoException(String message) {
        super(message);
    }
}
