package school.sptech.projetoMima.core.application.usecase.Item;


public class CadastrarItemUseCase {


}
