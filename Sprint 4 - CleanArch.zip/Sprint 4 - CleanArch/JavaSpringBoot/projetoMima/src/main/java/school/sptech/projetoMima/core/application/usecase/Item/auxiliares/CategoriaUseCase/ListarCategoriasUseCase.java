package school.sptech.projetoMima.core.application.usecase.Item.auxiliares.CategoriaUseCase;

public class ListarCategoriasUseCase { }
