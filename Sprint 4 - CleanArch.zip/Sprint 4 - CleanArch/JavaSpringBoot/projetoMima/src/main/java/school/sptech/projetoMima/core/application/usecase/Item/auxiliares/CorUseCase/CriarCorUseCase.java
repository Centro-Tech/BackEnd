package school.sptech.projetoMima.core.application.usecase.Item.auxiliares.CorUseCase;

public class CriarCorUseCase {
}
