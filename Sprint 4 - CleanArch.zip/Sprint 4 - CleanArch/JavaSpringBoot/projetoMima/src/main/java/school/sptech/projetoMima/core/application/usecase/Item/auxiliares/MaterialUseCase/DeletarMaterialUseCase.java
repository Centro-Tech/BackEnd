package school.sptech.projetoMima.core.application.usecase.Item.auxiliares.MaterialUseCase;

public class DeletarMaterialUseCase{ }