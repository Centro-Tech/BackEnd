package school.sptech.projetoMima.core.application.usecase.Item.auxiliares.TamanhoUseCase;

public record AtualizarTamanhoCommand(
        Integer id,
        String nome
) { }
