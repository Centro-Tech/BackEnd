package school.sptech.projetoMima.core.application.usecase.Item.auxiliares.TamanhoUseCase;

public class ListarTamanhosUseCase {
}
