package school.sptech.projetoMima.core.application.usecase.Venda;

import school.sptech.projetoMima.core.adapter.Cliente.ClienteGateway;
import school.sptech.projetoMima.core.adapter.Usuario.UsuarioGateway;
import school.sptech.projetoMima.core.adapter.Venda.VendaGateway;
import school.sptech.projetoMima.core.application.command.Venda.CreateVendaCommand;
import school.sptech.projetoMima.core.application.exception.Cliente.ClienteNaoEncontradoException;
import school.sptech.projetoMima.core.application.exception.Usuario.UsuarioNaoEncontradoException;
import school.sptech.projetoMima.core.domain.Cliente;
import school.sptech.projetoMima.core.domain.Usuario;
import school.sptech.projetoMima.core.domain.Venda;

import java.time.LocalDate;

public class CadastrarVendaUseCase {

    private final VendaGateway vendaGateway;
    private final ClienteGateway clienteGateway;
    private final UsuarioGateway usuarioGateway;

    public CadastrarVendaUseCase(VendaGateway vendaGateway,
                                 ClienteGateway clienteGateway,
                                 UsuarioGateway usuarioGateway) {
        this.vendaGateway = vendaGateway;
        this.clienteGateway = clienteGateway;
        this.usuarioGateway = usuarioGateway;
    }

    public Venda executar(CreateVendaCommand command) {
        // Buscar usuário
        Usuario usuario = usuarioGateway.findById(command.getUsuarioId())
                .orElseThrow(() -> new UsuarioNaoEncontradoException("Usuário não encontrado"));

        // Buscar cliente
        Cliente cliente = clienteGateway.findById(command.getClienteId());
                if (cliente == null) {
                    throw new ClienteNaoEncontradoException("Cliente não encontrado");
                }
        // ideal criar ClienteNaoEncontradoException

        // Montar nova venda
        Venda venda = new Venda();
        venda.setUsuario(usuario);
        venda.setCliente(cliente);
        venda.setData(LocalDate.now()); // ou LocalDate.now()
        venda.setValorTotal(command.getValorTotal());
        venda.getItensVenda(command.getItensVendaIds());

        // Se tiver itensVenda no command, carregar aqui também
        // venda.setItensVenda(...);

        return vendaGateway.save(venda);
    }
}
