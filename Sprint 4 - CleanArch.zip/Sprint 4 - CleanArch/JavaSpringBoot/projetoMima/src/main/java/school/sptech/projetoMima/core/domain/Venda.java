package school.sptech.projetoMima.core.domain;

import java.time.LocalDate;
import java.util.List;
public class Venda {

    private Integer id;

    private Double valorTotal = 0.0;

    private LocalDate data;

    private Cliente cliente;

    private Usuario usuario;

    private List<ItemVenda> itensVenda;  // <- corrigido de 'itemVenda' para 'itensVenda'

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<ItemVenda> getItensVenda(List<Integer> itensVendaIds) {
        return itensVenda;
    }

    public void setItensVenda(List<ItemVenda> itensVenda) {
        this.itensVenda = itensVenda;
    }

    // Métodos auxiliares para manter compatibilidade
    public Usuario getFuncionario() {
        return usuario;
    }

    public void setFuncionario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<Integer> getItensVendaIds() {
        return itensVenda.stream()
                .map(ItemVenda::getId)
                .toList();
    }

    //  public Usuario orElseThrow(Object usuárioNãoEncontrado) { return null;}
}
