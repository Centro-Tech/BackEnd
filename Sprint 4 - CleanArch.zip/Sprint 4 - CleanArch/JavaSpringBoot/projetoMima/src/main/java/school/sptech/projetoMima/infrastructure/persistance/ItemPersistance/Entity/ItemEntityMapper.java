package school.sptech.projetoMima.infrastructure.persistance.ItemPersistance.Entity;

public class ItemEntityMapper {
}
