package school.sptech.projetoMima.infrastructure.persistance.ItemPersistance.auxiliares.Categoria.Entity;

public class CategoriaEntity {
}
