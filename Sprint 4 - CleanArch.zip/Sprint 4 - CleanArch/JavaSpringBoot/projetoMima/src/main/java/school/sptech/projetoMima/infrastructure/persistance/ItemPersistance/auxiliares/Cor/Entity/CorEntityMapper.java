package school.sptech.projetoMima.infrastructure.persistance.ItemPersistance.auxiliares.Cor.Entity;

public class CorEntityMapper {
}
