package school.sptech.projetoMima.infrastructure.persistance.ItemPersistance.auxiliares.Material.Entity;

public class MaterialEntityMapper {
}
