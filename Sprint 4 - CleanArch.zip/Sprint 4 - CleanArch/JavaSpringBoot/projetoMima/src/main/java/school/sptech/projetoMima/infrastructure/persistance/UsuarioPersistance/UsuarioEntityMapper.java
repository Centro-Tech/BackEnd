package school.sptech.projetoMima.infrastructure.persistance.UsuarioPersistance;

import school.sptech.projetoMima.core.domain.Usuario;

public class UsuarioEntityMapper {

    public static UsuarioEntity toEntity(Usuario u) {
        UsuarioEntity e = new UsuarioEntity();
        e.setNome(u.getNome());
        e.setEmail(u.getEmail());
        e.setTelefone(u.getTelefone());
        e.setEndereco(u.getEndereco());
        e.setSenha(u.getSenha());
        e.setCargo(u.getCargo());
        return e;
    }

    public static Usuario toDomain(UsuarioEntity e) {
        return new Usuario(
                e.getNome(),
                e.getEmail(),
                e.getTelefone(),
                e.getEndereco(),
                e.getSenha(),
                e.getCargo()
        );
    }
}