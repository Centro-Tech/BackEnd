insert into usuario
(nome, email, senha)
values
    ('John Doe', 'john@doe.com', '$2a$10$0/TKTGxdREbWaWjWYhwf6e9P1fPOAMMNqEnZgOG95jnSkHSfkkIrC');
-- senha: 123456

INSERT INTO Fornecedor (nome, telefone, email)
VALUES ('Empresa XYZ LTDA', '11987654321', 'contato@empresa.com');

insert into Tamanho (nome) values
    ('M');

insert into Categoria (nome) values
    ('Camiseta');

insert into Cor (nome) values
    ('Preto');

insert into Material (nome) values
    ( 'Lã');
