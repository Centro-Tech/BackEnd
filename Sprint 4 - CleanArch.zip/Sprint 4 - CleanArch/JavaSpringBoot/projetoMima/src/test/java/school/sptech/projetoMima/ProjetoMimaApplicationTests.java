package school.sptech.projetoMima;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoMimaApplicationTests {

	@Test
	void contextLoads() {
	}

}
